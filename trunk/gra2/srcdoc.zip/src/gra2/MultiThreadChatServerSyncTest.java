/**
 * 
 */
package gra2;

import static org.junit.Assert.*;

import org.junit.*;

/**
 * 
 * 
 */
public class MultiThreadChatServerSyncTest {

	/**
	 * Test method for
	 * {@link gra2.MultiThreadChatServerSync#main(java.lang.String[])}.
	 */
	@BeforeClass
	public final void testMain() {
		String[] args;
		//MultiThreadChatServerSync.main(args).notNull();
	}


}
