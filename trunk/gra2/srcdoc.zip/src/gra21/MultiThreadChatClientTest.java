package gra21;

import static org.junit.Assert.*;

import org.junit.Test;

public class MultiThreadChatClientTest {

	@Test
	public void testMain() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRun() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testConstructComponentName() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetBackground() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddNotify() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveNotify() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveMenuComponent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testParamString() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAccessibleContext() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPostProcessKeyEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetIconImage() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetOpacity() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetShape() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFrame() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFrameGraphicsConfiguration() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFrameString() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFrameStringGraphicsConfiguration() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetTitle() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetTitle() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetIconImage() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMenuBar() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetMenuBar() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsResizable() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetResizable() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetState() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetExtendedState() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetState() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetExtendedState() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetMaximizedBounds() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMaximizedBounds() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetUndecorated() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsUndecorated() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetCursorInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetCursorType() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFrames() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetContainer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetGraphicsConfiguration() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetToolkit() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsRecursivelyVisible() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsShowing() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetVisible() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testShow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testClearMostRecentFocusOwnerOnHide() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testHide() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetBackground() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetLocale() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetLocationIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetLocationPoint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetSizeIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetSizeDimension() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetBoundsIntIntIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testReshape() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetBoundsRectangle() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsOpaque() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetMinimumSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetCursorCursor() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPaint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCreateBufferStrategyInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCreateBufferStrategyIntBufferCapabilities() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetBufferStrategy() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDispatchEventImpl() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDispatchMouseWheelToAncestor() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testEventEnabled() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPostEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAdjustListeningChildrenOnParent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetInputContext() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFocusTraversalKeys() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFocusCycleRootAncestor() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddPropertyChangeListenerPropertyChangeListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddPropertyChangeListenerStringPropertyChangeListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testApplyCompoundShape() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetLocationOnWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testApplyCurrentShape() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMixOnReshaping() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testUpdateZOrder() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCanContainFocusOwner() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAdjustDecendantsOnParent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsValidateRoot() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetFocusCycleRoot() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFocusCycleRoot() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPreProcessKeyEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testWindowGraphicsConfiguration() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testWindowFrame() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testWindowWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testWindowWindowGraphicsConfiguration() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetIconImages() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetIconImages() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPack() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetClientSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCloseSplashScreen() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testUpdateChildFocusableWindowState() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPostWindowEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDispose() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDisposeImpl() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDoDispose() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testToFront() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testToFront_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testToBack() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testToBack_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetWarningString() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetOwner() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetOwner_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetOwnedWindows() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetOwnedWindows_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsModalBlocked() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetModalBlocked() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetModalBlocker() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAllWindows() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAllUnblockedWindows() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetWindows() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetOwnerlessWindows() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetDocumentRoot() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetModalExclusionType() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetModalExclusionType() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsModalExcluded() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testUpdateChildrenBlocking() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddWindowListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddWindowStateListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddWindowFocusListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveWindowListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveWindowStateListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveWindowFocusListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetWindowListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetWindowFocusListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetWindowStateListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessWindowEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessWindowFocusEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessWindowStateEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetAlwaysOnTop() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsAlwaysOnTopSupported() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsAlwaysOnTop() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFocusOwner() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMostRecentFocusOwner() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsActive() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFocused() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFocusableWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFocusableWindowState() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetFocusableWindowState() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetAutoRequestFocus() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsAutoRequestFocus() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsDisposing() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testApplyResourceBundleResourceBundle() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testApplyResourceBundleString() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddOwnedWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveOwnedWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testConnectOwnedWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetType() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetType() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetLocationRelativeTo() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDeliverMouseWheelToAncestor() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetTemporaryLostComponent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetTemporaryLostComponent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetLocationByPlatform() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsLocationByPlatform() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetOpacity() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetShape() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testInitializeFocusTraversalKeys() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testUpdateGraphicsData() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCheckGD() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsSameOrAncestorOf() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testContainsFocus() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testClearCurrentFocusCycleRootOnHide() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testClearLightweightDispatcherOnRemove() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetFont() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetPreferredSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPreferredSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMinimumSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMinimumSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMaximumSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAlignmentX() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAlignmentY() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDoLayout() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testLayout() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testValidate() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testInvalidate() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testInvalidateParent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testUpdate() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testLightweightPaint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPaintHeavyweightComponents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPrint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testLightweightPrint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPrintHeavyweightComponents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetComponentAtIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testLocate() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetComponentAtPoint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDeliverEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testNumListening() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCountHierarchyMembers() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCreateHierarchyEvents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPostsOldMouseEvents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetFocusTraversalKeys() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAreFocusTraversalKeysSet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFocusCycleRootContainer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetTraversalRoot() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testListPrintStreamInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testListPrintWriterInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testApplyComponentOrientation() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetOpaqueShape() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMixOnShowing() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMixOnHiding() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMixOnZOrderChanging() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMixOnValidating() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testContainer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetComponentCount() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCountComponents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetComponent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetComponents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetComponents_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetComponentsSync() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetInsets() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testInsets() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddComponent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddStringComponent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddComponentInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testHasHeavyweightDescendants() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testHasLightweightDescendants() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetHeavyweightContainer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetComponentZOrder() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetComponentZOrder() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddComponentObject() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddComponentObjectInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddImpl() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveComponent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAdjustListeningChildren() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAdjustDescendants() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCreateChildHierarchyEvents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetLayout() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetLayout() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testValidateUnconditionally() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testValidateTree() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testInvalidateTree() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPaintComponents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPrintComponents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddContainerListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveContainerListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetContainerListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessContainerEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDispatchEventToSelf() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMouseEventTarget() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetDropTargetEventTarget() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProxyEnableEvents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMousePositionBoolean() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFindComponentAtIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFindComponentAtIntIntBoolean() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFindComponentAtImpl() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFindComponentAtPoint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsAncestorOf() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetFocusTraversalPolicy() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFocusTraversalPolicy() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFocusTraversalPolicySet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetFocusTraversalPolicyProvider() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFocusTraversalPolicyProvider() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testTransferFocusDownCycle() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAccessibleAt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAccessibleChildrenCount() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAccessibleChild() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIncreaseComponentCount() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDecreaseComponentCount() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRecursiveSubtractAndApplyShapeRegion() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRecursiveSubtractAndApplyShapeRegionInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRecursiveSubtractAndApplyShapeRegionIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRecursiveApplyCurrentShape() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRecursiveApplyCurrentShapeInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRecursiveApplyCurrentShapeIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsRecursivelyVisibleUpToHeavyweightContainer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testToString() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetObjectLock() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAccessControlContext() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetBoundsOp() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetBoundsOp() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testComponent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetName() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetName() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetParent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetParent_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetPeer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetDropTarget() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetDropTarget() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetGraphicsConfiguration() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetGraphicsConfiguration_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetTreeLock() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCheckTreeLock() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetToolkitImpl() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsValid() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsDisplayable() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsVisible() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsVisible_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPointRelativeToComponent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFindUnderMouseInWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMousePosition() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsEnabled() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsEnabledImpl() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetEnabled() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testEnable() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testEnableBoolean() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDisable() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsDoubleBuffered() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testEnableInputMethods() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testShowBoolean() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetForeground() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetForeground() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsForegroundSet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsBackgroundSet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFont() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFont_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFontSet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetLocale() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetColorModel() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetLocation() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetLocationOnScreen() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetLocationOnScreen_NoTreeLock() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testLocation() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMove() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testResizeIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testResizeDimension() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetBounds() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testBounds() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetX() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetY() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetWidth() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetHeight() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetBoundsRectangle() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetSizeDimension() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetLocationPoint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsLightweight() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetPreferredSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsPreferredSizeSet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsMinimumSizeSet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetMaximumSize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsMaximumSizeSet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetBaseline() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetBaselineResizeBehavior() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testInvalidateIfValid() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRevalidate() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRevalidateSynchronously() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetGraphics() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetGraphics_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFontMetrics() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testUpdateCursorImmediately() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetCursor() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetCursor_NoClientCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsCursorSet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPaintAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRepaint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRepaintLong() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRepaintIntIntIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRepaintLongIntIntIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPrintAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testImageUpdate() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCreateImageImageProducer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCreateImageIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCreateVolatileImageIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCreateVolatileImageIntIntImageCapabilities() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPrepareImageImageImageObserver() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testPrepareImageImageIntIntImageObserver() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCheckImageImageImageObserver() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCheckImageImageIntIntImageObserver() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetBackBuffer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetIgnoreRepaint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetIgnoreRepaint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testContainsIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testInside() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testContainsPoint() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDispatchEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAutoProcessMouseWheel() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCheckWindowClosingException() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAreInputMethodsEnabled() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testEventTypeEnabled() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddComponentListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveComponentListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetComponentListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddFocusListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveFocusListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFocusListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddHierarchyListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveHierarchyListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetHierarchyListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddHierarchyBoundsListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveHierarchyBoundsListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetHierarchyBoundsListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddKeyListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveKeyListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetKeyListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddMouseListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveMouseListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMouseListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddMouseMotionListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveMouseMotionListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMouseMotionListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddMouseWheelListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveMouseWheelListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetMouseWheelListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddInputMethodListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemoveInputMethodListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetInputMethodListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetInputMethodRequests() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testEnableEvents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testDisableEvents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsCoalescingEnabled() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCoalesceEvents() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessComponentEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessFocusEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessKeyEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessMouseEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessMouseMotionEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessMouseWheelEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessInputMethodEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessHierarchyEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testProcessHierarchyBoundsEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testHandleEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMouseDown() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMouseDrag() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMouseUp() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMouseMove() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMouseEnter() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testMouseExit() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testKeyDown() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testKeyUp() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAction() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGotFocus() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testLostFocus() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFocusTraversable() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFocusable() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetFocusable() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFocusTraversableOverridden() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetFocusTraversalKeys_NoIDCheck() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFocusTraversalKeys_NoIDCheck() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetFocusTraversalKeysEnabled() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetFocusTraversalKeysEnabled() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRequestFocus() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRequestFocusCause() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRequestFocusBoolean() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRequestFocusBooleanCause() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRequestFocusInWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRequestFocusInWindowCause() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRequestFocusInWindowBoolean() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRequestFocusInWindowBooleanCause() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRequestFocusHelperBooleanBoolean() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRequestFocusHelperBooleanBooleanCause() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetRequestFocusController() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testTransferFocus() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testNextFocus() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testTransferFocusBoolean() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetNextFocusCandidate() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testTransferFocusBackward() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testTransferFocusBackwardBoolean() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testTransferFocusUpCycle() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testHasFocus() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsFocusOwner() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetAutoFocusTransferOnDisposal() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsAutoFocusTransferOnDisposal() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAddPopupMenu() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testList() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testListPrintStream() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testListPrintWriter() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetNativeContainer() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemovePropertyChangeListenerPropertyChangeListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetPropertyChangeListeners() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRemovePropertyChangeListenerStringPropertyChangeListener() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetPropertyChangeListenersString() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFirePropertyChangeStringObjectObject() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFirePropertyChangeStringBooleanBoolean() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFirePropertyChangeStringIntInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFirePropertyChangeStringByteByte() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFirePropertyChangeStringCharChar() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFirePropertyChangeStringShortShort() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFirePropertyChangeStringLongLong() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFirePropertyChangeStringFloatFloat() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFirePropertyChangeStringDoubleDouble() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSetComponentOrientation() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetComponentOrientation() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCanBeFocusOwner() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCanBeFocusOwnerRecursively() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testRelocateComponent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetContainingWindow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAccessibleIndexInParent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetAccessibleStateSet() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsInstanceOf() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testAreBoundsValid() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetNormalShape() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetSiblingIndexAbove() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetHWPeerAboveMe() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetSiblingIndexBelow() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsNonOpaqueForMixing() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSubtractAndApplyShape() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testSubtractAndApplyShapeBelowMe() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testIsMixingNeeded() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testObject() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testGetClass() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testHashCode() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testEquals() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testClone() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testNotify() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testNotifyAll() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testWaitLong() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testWaitLongInt() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testWait() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testFinalize() {
		fail("Not yet implemented"); // TODO
	}

}
