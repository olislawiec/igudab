package gra2;

public class Gui {

	public Gui() {
		
	}

}
