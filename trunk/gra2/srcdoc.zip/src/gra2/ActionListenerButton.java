package gra2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionListenerButton implements ActionListener {

    /**
     * 
     * @param arg0 argument akcji 
     */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		
	}

}
