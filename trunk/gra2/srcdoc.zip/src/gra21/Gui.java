package gra21;

public class Gui {

	public Gui() {
		
	}

}
